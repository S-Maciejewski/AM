# mvx-custom-binding

[![MvvmCross](https://avatars1.githubusercontent.com/u/3919206?s=80&v=4)](https://www.mvvmcross.com/)

##### Simple MvvmCross custom data binding example on Android 

![image](screen.gif)

##### Added example of a notification 

![image](notification.gif)
