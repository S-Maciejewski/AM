﻿namespace MvxCustomBinding
{
    public interface INotificationService
    {
        void Notify();
    }
}
