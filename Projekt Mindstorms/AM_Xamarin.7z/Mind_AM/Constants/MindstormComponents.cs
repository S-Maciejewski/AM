﻿
namespace Mind_AM.Constants
{
    public static class MindstormComponents
    {
        // Motors
        public const int MotorA = 0;

        public const int MotorB = 1;
    }
}